<?php
/**
 * @file plugins/themes/pustakaMinang/PustakaMinangThemePlugin.php
 *
 * Custom theme for Pustaka Inspirasi Minang.
 */

namespace APP\plugins\themes\pustakaMinang;

class PustakaMinangThemePlugin extends \PKP\plugins\ThemePlugin
{
    /**
     * Initialize the theme's styles, scripts and hooks.
     */
    public function init()
    {
        error_log("pustakaMinang Theme init called!");
        // Inherit all styles, scripts, and behaviors from the default theme
        $this->setParent('defaultthemeplugin');

        // Add our custom CSS overrides for MDPI-style UI/UX and Marawa branding
        $this->addStyle('pustaka-minang-layout', 'styles/pim-layout.css');
        $this->addStyle('pustaka-minang-style', 'styles/custom.css');
    }

    /**
     * Get the display name of this plugin
     *
     * @return string
     */
    public function getDisplayName()
    {
        return 'Pustaka Inspirasi Minang Theme';
    }

    /**
     * Get the description of this plugin
     *
     * @return string
     */
    public function getDescription()
    {
        return 'A premium academic theme with modern UI/UX inspired by MDPI and GPI Journal, styled with traditional Minang Marawa colors and design accents.';
    }
}
